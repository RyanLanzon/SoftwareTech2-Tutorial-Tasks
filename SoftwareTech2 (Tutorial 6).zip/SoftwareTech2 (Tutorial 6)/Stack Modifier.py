import tkinter as tk
from tkinter import messagebox

NODE_WIDTH = 60
NODE_HEIGHT = 40
HORIZONTAL_GAP = 40
CANVAS_HEIGHT = 120
CANVAS_WIDTH = 900

class QueueVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualizer")

        self.queue = []

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg='white')
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        tk.Label(control_frame, text="Value:").grid(row=0, column=0)
        self.value_entry = tk.Entry(control_frame, width=5)
        self.value_entry.grid(row=0, column=1)

        enqueue_btn = tk.Button(control_frame, text="Enqueue", command=self.enqueue)
        enqueue_btn.grid(row=0, column=2)

        dequeue_btn = tk.Button(control_frame, text="Dequeue", command=self.dequeue)
        dequeue_btn.grid(row=0, column=3)

        self.draw_queue()

    def draw_queue(self):
        self.canvas.delete("all")

        x = 20
        y = 40

        for i, val in enumerate(self.queue):

            self.canvas.create_rectangle(
                x, y, x + NODE_WIDTH, y + NODE_HEIGHT,
                fill="lightgrey", outline="black", width=2
            )

            self.canvas.create_text(
                x + NODE_WIDTH//2, y + NODE_HEIGHT//2,
                text=str(val), font=("Arial", 16)
            )

            if i < len(self.queue)-1:
                self.canvas.create_line(
                    x + NODE_WIDTH, y + NODE_HEIGHT/2,
                    x + NODE_WIDTH + HORIZONTAL_GAP, y + NODE_HEIGHT/2,
                    arrow=tk.LAST, width=2
                )

            x += NODE_WIDTH + HORIZONTAL_GAP

    def enqueue(self):
        try:
            val = int(self.value_entry.get())
        except ValueError:
            messagebox.showerror("Error", "Enter an integer")
            return

        self.queue.append(val)
        self.draw_queue()

    def dequeue(self):
        if len(self.queue) == 0:
            messagebox.showerror("Error", "Queue is empty")
            return

        self.queue.pop(0)
        self.draw_queue()

if __name__ == "__main__":
    root = tk.Tk()
    app = QueueVisualizer(root)

    app.queue = [10,20,30,40,50]
    app.draw_queue()

    root.mainloop()