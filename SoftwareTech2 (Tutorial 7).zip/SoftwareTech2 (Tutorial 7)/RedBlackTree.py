import tkinter as tk

class RBNode:
    def __init__(self, value, color="red"):
        self.value = value
        self.color = color
        self.left = None
        self.right = None

class RBTree:
    def __init__(self):
        self.root = None

    def insert(self, root, value, is_root=False):
        if root is None:
            if is_root:
                return RBNode(value, "black")
            return RBNode(value, "red")

        if value < root.value:
            root.left = self.insert(root.left, value)
        else:
            root.right = self.insert(root.right, value)

        return root

    def insert_value(self, value):
        self.root = self.insert(self.root, value, is_root=(self.root is None))

class RBApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Red-Black Tree (Simple Visual)")

        self.tree = RBTree()

        frame = tk.Frame(root)
        frame.pack(pady=10)

        self.entry = tk.Entry(frame)
        self.entry.pack(side=tk.LEFT)

        tk.Button(frame, text="Insert", command=self.insert_value).pack(side=tk.LEFT)

        self.canvas = tk.Canvas(root, width=900, height=500, bg="white")
        self.canvas.pack()

    def insert_value(self):
        try:
            val = int(self.entry.get())
        except:
            return

        self.tree.insert_value(val)
        self.entry.delete(0, tk.END)
        self.draw_tree()

    def draw_tree(self):
        self.canvas.delete("all")
        self._draw(self.tree.root, 450, 50, 180)

    def _draw(self, node, x, y, offset):
        if node is None:
            return

        fill_color = "red" if node.color == "red" else "black"
        text_color = "black" if node.color == "red" else "white"

        if node.left:
            self.canvas.create_line(x, y, x - offset, y + 80)
            self._draw(node.left, x - offset, y + 80, max(offset // 2, 40))

        if node.right:
            self.canvas.create_line(x, y, x + offset, y + 80)
            self._draw(node.right, x + offset, y + 80, max(offset // 2, 40))

        self.canvas.create_oval(x - 22, y - 22, x + 22, y + 22, fill=fill_color, outline="black")
        self.canvas.create_text(x, y, text=str(node.value), fill=text_color, font=("Arial", 11, "bold"))

if __name__ == "__main__":
    root = tk.Tk()
    app = RBApp(root)
    root.mainloop()